﻿using System.Web.UI;

namespace CSE445_Assignment5.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}